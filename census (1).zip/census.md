

```python
# Dependencies
import json
import requests
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib import style
from matplotlib import style
import matplotlib.ticker as tkr
from pylab import *
from matplotlib.font_manager import FontProperties
```


```python
api_key = '3286c138a388ef8b9e598517a438a480860463e3'
```


```python

url = 'https://api.census.gov/data/2013/acs1?get=NAME,B01003_001E,B15003_017E,B15003_021E,B15003_023E,B15003_022E,B15003_024E,B15003_025E,B21001_002E,B21001_003E,B02008_001E,B02009_001E,B02010_001E,B02011_001E,B02012_001E,B02013_001E,B05001_002E,B05001_006E,B17001_002E,B24050_002E,B24050_005E,B24050_006E,B24050_007E,B24050_008E,B24050_009E,B24050_012E,B24050_013E,B24050_016E,B24050_020E,B24050_023E,B24050_027E,B12006_001E,B23004_001E,B23025_005E&for=congressional%20district:*&key='
#url = 'https://api.census.gov/data/2016/acs1?get=*&for=metropolitan%20statistical%20area/micropolitan%20statistical%20area:*&key='

key_url = url + api_key
```


```python
#base_url = 'https://api.census.gov/data/'
#year = '2016/'
#datasetAcronym = 'acs1/'
#query = '?get='

#full_url = base_url + year + datasetAcronym

#https://api.census.gov/data/2013/acs1?get=NAME,B02015_009E,B02015_009M&for=state:*&key=your key here

columns = {'NAME': 'Name of District',
            'B01003_001E' : 'Total Population',
            'metropolitan statistical area/micropolitan statistical area' : 'Area ID',
            "B15003_021E" : "Associates Degree", 
            "B15003_017E" : "High School Diploma", 
            "B15003_022E" : "Bachelor's", 
            "B15003_023E" : "Masters" , 
            "B15003_024E" : "Professional" , 
            "B15003_025E" : "Doctorate",
            "B21001_002E" : "Veteran",
            "B21001_003E" : "Non-Veteran",
            "B02008_001E" : "White", 
            "B02009_001E" : "African American",
            "B02010_001E" : "Native American/Alaskan",
            "B02011_001E" : "Asian",
            "B02012_001E" : "Native Hawaiian/Pacific Islander",
            "B02013_001E" : "OtherRace",
            'B05001_002E' : 'U.S. citizen',
            'B05001_006E' : 'Non U.S. citizen',
            "B17001_002E" : "Income in the past 12 months below poverty level",
            "B24050_002E" : "Agriculture, forestry, fishing and hunting, and mining",
            "B24050_005E" : "Construction",
            "B24050_006E" : "Manufacturing",
            "B24050_007E" : "Wholesale Trade",
            "B24050_008E" : "Retail Trade",
            "B24050_009E" : "Transportation and warehousing, and utilities",
            "B24050_012E" : "INFORMATION",
            "B24050_013E" : "Finance and insurance, and real estate and rental and leasing",
            "B24050_016E" : "Professional, scientific, and management, and administrative and waste management services",  
            "B24050_020E" : "Educational services, and health care and social assistance",
            "B24050_023E" : "Arts, entertainment, and recreation, and accommodation and food services",
            "B24050_027E" : "Public Administration",
            "B12006_001E" : "TotalLaborPopulation",
            "B23025_005E" : "Total Unemployed"
           
           
          }

```


```python
census_response = requests.get(key_url)
census_json = census_response.json()

dataFrame =pd.DataFrame(census_json)
dataFrame.columns = dataFrame.iloc[0]
dataFrame = dataFrame.drop([0])
dataFrame = dataFrame.rename(columns=columns)
```


```python
dataFrame

```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Name of District</th>
      <th>Total Population</th>
      <th>High School Diploma</th>
      <th>Associates Degree</th>
      <th>Masters</th>
      <th>Bachelor's</th>
      <th>Professional</th>
      <th>Doctorate</th>
      <th>Veteran</th>
      <th>Non-Veteran</th>
      <th>...</th>
      <th>Finance and insurance, and real estate and rental and leasing</th>
      <th>Professional, scientific, and management, and administrative and waste management services</th>
      <th>Educational services, and health care and social assistance</th>
      <th>Arts, entertainment, and recreation, and accommodation and food services</th>
      <th>Public Administration</th>
      <th>TotalLaborPopulation</th>
      <th>B23004_001E</th>
      <th>Total Unemployed</th>
      <th>state</th>
      <th>congressional district</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>Congressional District 1 (113th Congress), Ala...</td>
      <td>695176</td>
      <td>126702</td>
      <td>42633</td>
      <td>23595</td>
      <td>72934</td>
      <td>5941</td>
      <td>3795</td>
      <td>52723</td>
      <td>477331</td>
      <td>...</td>
      <td>15888</td>
      <td>25525</td>
      <td>64078</td>
      <td>30570</td>
      <td>11190</td>
      <td>549129</td>
      <td>108060</td>
      <td>35769</td>
      <td>01</td>
      <td>01</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Congressional District 2 (113th Congress), Ala...</td>
      <td>690074</td>
      <td>120918</td>
      <td>36495</td>
      <td>27888</td>
      <td>57610</td>
      <td>4791</td>
      <td>3695</td>
      <td>63027</td>
      <td>459492</td>
      <td>...</td>
      <td>12942</td>
      <td>20555</td>
      <td>59887</td>
      <td>24293</td>
      <td>24652</td>
      <td>545050</td>
      <td>103909</td>
      <td>29884</td>
      <td>01</td>
      <td>02</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Congressional District 3 (113th Congress), Ala...</td>
      <td>697761</td>
      <td>122707</td>
      <td>32578</td>
      <td>29049</td>
      <td>55675</td>
      <td>5384</td>
      <td>6147</td>
      <td>52505</td>
      <td>487150</td>
      <td>...</td>
      <td>14637</td>
      <td>21083</td>
      <td>67465</td>
      <td>27035</td>
      <td>18921</td>
      <td>560022</td>
      <td>100287</td>
      <td>31737</td>
      <td>01</td>
      <td>03</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Congressional District 4 (113th Congress), Ala...</td>
      <td>685175</td>
      <td>127289</td>
      <td>42214</td>
      <td>20847</td>
      <td>46061</td>
      <td>4374</td>
      <td>3450</td>
      <td>44314</td>
      <td>485012</td>
      <td>...</td>
      <td>10358</td>
      <td>18184</td>
      <td>59296</td>
      <td>17977</td>
      <td>11396</td>
      <td>546746</td>
      <td>114110</td>
      <td>28388</td>
      <td>01</td>
      <td>04</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Congressional District 5 (113th Congress), Ala...</td>
      <td>701220</td>
      <td>103980</td>
      <td>39078</td>
      <td>38772</td>
      <td>90232</td>
      <td>5092</td>
      <td>5863</td>
      <td>56285</td>
      <td>486201</td>
      <td>...</td>
      <td>13300</td>
      <td>42708</td>
      <td>61177</td>
      <td>22079</td>
      <td>21636</td>
      <td>562069</td>
      <td>103466</td>
      <td>31393</td>
      <td>01</td>
      <td>05</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Congressional District 6 (113th Congress), Ala...</td>
      <td>697436</td>
      <td>104687</td>
      <td>31906</td>
      <td>42790</td>
      <td>101090</td>
      <td>14402</td>
      <td>6337</td>
      <td>46949</td>
      <td>483336</td>
      <td>...</td>
      <td>29927</td>
      <td>30020</td>
      <td>78968</td>
      <td>24274</td>
      <td>11128</td>
      <td>548676</td>
      <td>100382</td>
      <td>19303</td>
      <td>01</td>
      <td>06</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Congressional District 7 (113th Congress), Ala...</td>
      <td>666880</td>
      <td>118193</td>
      <td>33206</td>
      <td>19494</td>
      <td>52414</td>
      <td>4915</td>
      <td>4316</td>
      <td>39593</td>
      <td>478523</td>
      <td>...</td>
      <td>12787</td>
      <td>23090</td>
      <td>70003</td>
      <td>23346</td>
      <td>11257</td>
      <td>533863</td>
      <td>91324</td>
      <td>37794</td>
      <td>01</td>
      <td>07</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Congressional District (at Large) (113th Congr...</td>
      <td>735132</td>
      <td>106234</td>
      <td>38486</td>
      <td>32966</td>
      <td>84038</td>
      <td>7246</td>
      <td>5163</td>
      <td>63023</td>
      <td>467410</td>
      <td>...</td>
      <td>15201</td>
      <td>33271</td>
      <td>79891</td>
      <td>30891</td>
      <td>35883</td>
      <td>565724</td>
      <td>65584</td>
      <td>33687</td>
      <td>02</td>
      <td>00</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Congressional District 1 (113th Congress), Ari...</td>
      <td>723969</td>
      <td>103874</td>
      <td>41735</td>
      <td>29171</td>
      <td>64852</td>
      <td>5487</td>
      <td>7071</td>
      <td>57577</td>
      <td>487255</td>
      <td>...</td>
      <td>12377</td>
      <td>17694</td>
      <td>68762</td>
      <td>35516</td>
      <td>21252</td>
      <td>565891</td>
      <td>116722</td>
      <td>36250</td>
      <td>04</td>
      <td>01</td>
    </tr>
    <tr>
      <th>10</th>
      <td>Congressional District 2 (113th Congress), Ari...</td>
      <td>717970</td>
      <td>83881</td>
      <td>42352</td>
      <td>46535</td>
      <td>91298</td>
      <td>10619</td>
      <td>11557</td>
      <td>73583</td>
      <td>489100</td>
      <td>...</td>
      <td>18836</td>
      <td>36415</td>
      <td>76576</td>
      <td>33970</td>
      <td>24132</td>
      <td>585319</td>
      <td>136486</td>
      <td>30873</td>
      <td>04</td>
      <td>02</td>
    </tr>
    <tr>
      <th>11</th>
      <td>Congressional District 3 (113th Congress), Ari...</td>
      <td>722963</td>
      <td>100427</td>
      <td>31615</td>
      <td>16531</td>
      <td>41668</td>
      <td>3213</td>
      <td>3270</td>
      <td>39639</td>
      <td>481022</td>
      <td>...</td>
      <td>13160</td>
      <td>28481</td>
      <td>63497</td>
      <td>31511</td>
      <td>21614</td>
      <td>547207</td>
      <td>75437</td>
      <td>40716</td>
      <td>04</td>
      <td>03</td>
    </tr>
    <tr>
      <th>12</th>
      <td>Congressional District 4 (113th Congress), Ari...</td>
      <td>732689</td>
      <td>138997</td>
      <td>45806</td>
      <td>24570</td>
      <td>56904</td>
      <td>5177</td>
      <td>4416</td>
      <td>82977</td>
      <td>491937</td>
      <td>...</td>
      <td>14608</td>
      <td>21736</td>
      <td>51441</td>
      <td>37498</td>
      <td>17282</td>
      <td>595388</td>
      <td>176026</td>
      <td>30629</td>
      <td>04</td>
      <td>04</td>
    </tr>
    <tr>
      <th>13</th>
      <td>Congressional District 5 (113th Congress), Ari...</td>
      <td>759102</td>
      <td>89171</td>
      <td>48921</td>
      <td>47311</td>
      <td>110765</td>
      <td>8638</td>
      <td>6668</td>
      <td>54020</td>
      <td>496883</td>
      <td>...</td>
      <td>32792</td>
      <td>38442</td>
      <td>74872</td>
      <td>28519</td>
      <td>12718</td>
      <td>572925</td>
      <td>113672</td>
      <td>20916</td>
      <td>04</td>
      <td>05</td>
    </tr>
    <tr>
      <th>14</th>
      <td>Congressional District 6 (113th Congress), Ari...</td>
      <td>737884</td>
      <td>89280</td>
      <td>44272</td>
      <td>55049</td>
      <td>136977</td>
      <td>18061</td>
      <td>7289</td>
      <td>51551</td>
      <td>530818</td>
      <td>...</td>
      <td>43503</td>
      <td>55593</td>
      <td>79489</td>
      <td>34401</td>
      <td>13616</td>
      <td>599775</td>
      <td>120275</td>
      <td>26972</td>
      <td>04</td>
      <td>06</td>
    </tr>
    <tr>
      <th>15</th>
      <td>Congressional District 7 (113th Congress), Ari...</td>
      <td>749222</td>
      <td>95337</td>
      <td>24043</td>
      <td>12996</td>
      <td>37990</td>
      <td>2968</td>
      <td>1679</td>
      <td>25646</td>
      <td>486130</td>
      <td>...</td>
      <td>18330</td>
      <td>41145</td>
      <td>47068</td>
      <td>34303</td>
      <td>9000</td>
      <td>537334</td>
      <td>47275</td>
      <td>37671</td>
      <td>04</td>
      <td>07</td>
    </tr>
    <tr>
      <th>16</th>
      <td>Congressional District 8 (113th Congress), Ari...</td>
      <td>741374</td>
      <td>118265</td>
      <td>49355</td>
      <td>39660</td>
      <td>94723</td>
      <td>7860</td>
      <td>4780</td>
      <td>74179</td>
      <td>495548</td>
      <td>...</td>
      <td>31016</td>
      <td>33011</td>
      <td>66355</td>
      <td>26330</td>
      <td>17200</td>
      <td>590472</td>
      <td>157501</td>
      <td>19715</td>
      <td>04</td>
      <td>08</td>
    </tr>
    <tr>
      <th>17</th>
      <td>Congressional District 9 (113th Congress), Ari...</td>
      <td>741451</td>
      <td>83079</td>
      <td>46778</td>
      <td>48147</td>
      <td>106805</td>
      <td>10064</td>
      <td>7672</td>
      <td>39713</td>
      <td>538504</td>
      <td>...</td>
      <td>30381</td>
      <td>58683</td>
      <td>90974</td>
      <td>43195</td>
      <td>14317</td>
      <td>597375</td>
      <td>75330</td>
      <td>29868</td>
      <td>04</td>
      <td>09</td>
    </tr>
    <tr>
      <th>18</th>
      <td>Congressional District 1 (113th Congress), Ark...</td>
      <td>729971</td>
      <td>154217</td>
      <td>30377</td>
      <td>17442</td>
      <td>51794</td>
      <td>2795</td>
      <td>2650</td>
      <td>57035</td>
      <td>499110</td>
      <td>...</td>
      <td>11660</td>
      <td>14823</td>
      <td>72583</td>
      <td>22202</td>
      <td>10940</td>
      <td>578006</td>
      <td>122096</td>
      <td>31412</td>
      <td>05</td>
      <td>01</td>
    </tr>
    <tr>
      <th>19</th>
      <td>Congressional District 2 (113th Congress), Ark...</td>
      <td>751463</td>
      <td>130211</td>
      <td>31904</td>
      <td>34364</td>
      <td>84551</td>
      <td>8795</td>
      <td>6611</td>
      <td>57679</td>
      <td>513285</td>
      <td>...</td>
      <td>22319</td>
      <td>26952</td>
      <td>88885</td>
      <td>30463</td>
      <td>21281</td>
      <td>592820</td>
      <td>106527</td>
      <td>25781</td>
      <td>05</td>
      <td>02</td>
    </tr>
    <tr>
      <th>20</th>
      <td>Congressional District 3 (113th Congress), Ark...</td>
      <td>757765</td>
      <td>125413</td>
      <td>27152</td>
      <td>31867</td>
      <td>76110</td>
      <td>8519</td>
      <td>4568</td>
      <td>49576</td>
      <td>515874</td>
      <td>...</td>
      <td>13449</td>
      <td>29625</td>
      <td>71215</td>
      <td>27783</td>
      <td>8573</td>
      <td>584047</td>
      <td>100290</td>
      <td>22469</td>
      <td>05</td>
      <td>03</td>
    </tr>
    <tr>
      <th>21</th>
      <td>Congressional District 4 (113th Congress), Ark...</td>
      <td>720174</td>
      <td>161091</td>
      <td>30379</td>
      <td>17618</td>
      <td>50300</td>
      <td>3008</td>
      <td>2945</td>
      <td>54299</td>
      <td>496776</td>
      <td>...</td>
      <td>11227</td>
      <td>17701</td>
      <td>68514</td>
      <td>22050</td>
      <td>13798</td>
      <td>570295</td>
      <td>124629</td>
      <td>29655</td>
      <td>05</td>
      <td>04</td>
    </tr>
    <tr>
      <th>22</th>
      <td>Congressional District 1 (113th Congress), Cal...</td>
      <td>707992</td>
      <td>105669</td>
      <td>49784</td>
      <td>26232</td>
      <td>71974</td>
      <td>8656</td>
      <td>3581</td>
      <td>60856</td>
      <td>502790</td>
      <td>...</td>
      <td>14461</td>
      <td>25754</td>
      <td>69167</td>
      <td>28163</td>
      <td>18358</td>
      <td>581612</td>
      <td>133755</td>
      <td>30799</td>
      <td>06</td>
      <td>01</td>
    </tr>
    <tr>
      <th>23</th>
      <td>Congressional District 2 (113th Congress), Cal...</td>
      <td>713816</td>
      <td>84908</td>
      <td>40584</td>
      <td>47428</td>
      <td>119850</td>
      <td>19841</td>
      <td>10336</td>
      <td>46452</td>
      <td>520445</td>
      <td>...</td>
      <td>25267</td>
      <td>42190</td>
      <td>74897</td>
      <td>30716</td>
      <td>17737</td>
      <td>583852</td>
      <td>124276</td>
      <td>31274</td>
      <td>06</td>
      <td>02</td>
    </tr>
    <tr>
      <th>24</th>
      <td>Congressional District 3 (113th Congress), Cal...</td>
      <td>714407</td>
      <td>94986</td>
      <td>39791</td>
      <td>23525</td>
      <td>66547</td>
      <td>8696</td>
      <td>7434</td>
      <td>49809</td>
      <td>482094</td>
      <td>...</td>
      <td>14389</td>
      <td>28695</td>
      <td>68561</td>
      <td>29185</td>
      <td>20584</td>
      <td>557778</td>
      <td>88809</td>
      <td>37716</td>
      <td>06</td>
      <td>03</td>
    </tr>
    <tr>
      <th>25</th>
      <td>Congressional District 4 (113th Congress), Cal...</td>
      <td>703377</td>
      <td>99355</td>
      <td>50667</td>
      <td>38110</td>
      <td>103309</td>
      <td>11932</td>
      <td>5314</td>
      <td>58876</td>
      <td>494553</td>
      <td>...</td>
      <td>22227</td>
      <td>32664</td>
      <td>65081</td>
      <td>34874</td>
      <td>20771</td>
      <td>572104</td>
      <td>132228</td>
      <td>34398</td>
      <td>06</td>
      <td>04</td>
    </tr>
    <tr>
      <th>26</th>
      <td>Congressional District 5 (113th Congress), Cal...</td>
      <td>715332</td>
      <td>91902</td>
      <td>47902</td>
      <td>29886</td>
      <td>97950</td>
      <td>12616</td>
      <td>5982</td>
      <td>45665</td>
      <td>518676</td>
      <td>...</td>
      <td>22072</td>
      <td>34037</td>
      <td>75957</td>
      <td>37964</td>
      <td>14929</td>
      <td>582817</td>
      <td>109450</td>
      <td>35337</td>
      <td>06</td>
      <td>05</td>
    </tr>
    <tr>
      <th>27</th>
      <td>Congressional District 6 (113th Congress), Cal...</td>
      <td>729428</td>
      <td>101557</td>
      <td>39924</td>
      <td>27607</td>
      <td>77776</td>
      <td>8507</td>
      <td>5205</td>
      <td>37899</td>
      <td>508278</td>
      <td>...</td>
      <td>21596</td>
      <td>37170</td>
      <td>61985</td>
      <td>28245</td>
      <td>32764</td>
      <td>565953</td>
      <td>82431</td>
      <td>46224</td>
      <td>06</td>
      <td>06</td>
    </tr>
    <tr>
      <th>28</th>
      <td>Congressional District 7 (113th Congress), Cal...</td>
      <td>721042</td>
      <td>91300</td>
      <td>52355</td>
      <td>35892</td>
      <td>99943</td>
      <td>11866</td>
      <td>4869</td>
      <td>48303</td>
      <td>496953</td>
      <td>...</td>
      <td>26055</td>
      <td>35787</td>
      <td>68602</td>
      <td>28353</td>
      <td>31404</td>
      <td>568391</td>
      <td>98481</td>
      <td>39982</td>
      <td>06</td>
      <td>07</td>
    </tr>
    <tr>
      <th>29</th>
      <td>Congressional District 8 (113th Congress), Cal...</td>
      <td>709384</td>
      <td>112094</td>
      <td>42689</td>
      <td>18826</td>
      <td>37981</td>
      <td>4346</td>
      <td>2595</td>
      <td>45040</td>
      <td>462488</td>
      <td>...</td>
      <td>14910</td>
      <td>18991</td>
      <td>54427</td>
      <td>26470</td>
      <td>18936</td>
      <td>538434</td>
      <td>86553</td>
      <td>37748</td>
      <td>06</td>
      <td>08</td>
    </tr>
    <tr>
      <th>30</th>
      <td>Congressional District 9 (113th Congress), Cal...</td>
      <td>724907</td>
      <td>96612</td>
      <td>44300</td>
      <td>14436</td>
      <td>61304</td>
      <td>5524</td>
      <td>3887</td>
      <td>35139</td>
      <td>488097</td>
      <td>...</td>
      <td>18171</td>
      <td>24451</td>
      <td>65591</td>
      <td>26788</td>
      <td>15159</td>
      <td>546443</td>
      <td>88040</td>
      <td>42124</td>
      <td>06</td>
      <td>09</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>408</th>
      <td>Congressional District 5 (113th Congress), Vir...</td>
      <td>735799</td>
      <td>127818</td>
      <td>36599</td>
      <td>38466</td>
      <td>78659</td>
      <td>9559</td>
      <td>9893</td>
      <td>55131</td>
      <td>524952</td>
      <td>...</td>
      <td>14819</td>
      <td>32083</td>
      <td>88761</td>
      <td>24666</td>
      <td>20936</td>
      <td>598223</td>
      <td>130434</td>
      <td>20880</td>
      <td>51</td>
      <td>05</td>
    </tr>
    <tr>
      <th>409</th>
      <td>Congressional District 6 (113th Congress), Vir...</td>
      <td>735143</td>
      <td>135423</td>
      <td>32541</td>
      <td>31546</td>
      <td>79796</td>
      <td>7787</td>
      <td>5415</td>
      <td>53787</td>
      <td>529829</td>
      <td>...</td>
      <td>17457</td>
      <td>27317</td>
      <td>88794</td>
      <td>35941</td>
      <td>13838</td>
      <td>601817</td>
      <td>123661</td>
      <td>26594</td>
      <td>51</td>
      <td>06</td>
    </tr>
    <tr>
      <th>410</th>
      <td>Congressional District 7 (113th Congress), Vir...</td>
      <td>760928</td>
      <td>112128</td>
      <td>36572</td>
      <td>52865</td>
      <td>124799</td>
      <td>13093</td>
      <td>8729</td>
      <td>57162</td>
      <td>524214</td>
      <td>...</td>
      <td>42136</td>
      <td>47385</td>
      <td>88992</td>
      <td>31109</td>
      <td>26174</td>
      <td>602572</td>
      <td>107567</td>
      <td>25772</td>
      <td>51</td>
      <td>07</td>
    </tr>
    <tr>
      <th>411</th>
      <td>Congressional District 8 (113th Congress), Vir...</td>
      <td>774396</td>
      <td>62929</td>
      <td>26423</td>
      <td>118245</td>
      <td>168288</td>
      <td>35028</td>
      <td>19848</td>
      <td>51623</td>
      <td>549927</td>
      <td>...</td>
      <td>28811</td>
      <td>106952</td>
      <td>69018</td>
      <td>46544</td>
      <td>67088</td>
      <td>625112</td>
      <td>78309</td>
      <td>21672</td>
      <td>51</td>
      <td>08</td>
    </tr>
    <tr>
      <th>412</th>
      <td>Congressional District 9 (113th Congress), Vir...</td>
      <td>721531</td>
      <td>136987</td>
      <td>43839</td>
      <td>27089</td>
      <td>54144</td>
      <td>5453</td>
      <td>7791</td>
      <td>45922</td>
      <td>538768</td>
      <td>...</td>
      <td>10231</td>
      <td>21981</td>
      <td>80682</td>
      <td>25087</td>
      <td>15584</td>
      <td>602862</td>
      <td>130679</td>
      <td>22513</td>
      <td>51</td>
      <td>09</td>
    </tr>
    <tr>
      <th>413</th>
      <td>Congressional District 10 (113th Congress), Vi...</td>
      <td>781947</td>
      <td>71086</td>
      <td>30763</td>
      <td>86480</td>
      <td>159581</td>
      <td>16275</td>
      <td>9542</td>
      <td>52678</td>
      <td>510688</td>
      <td>...</td>
      <td>29774</td>
      <td>92245</td>
      <td>69332</td>
      <td>28387</td>
      <td>34095</td>
      <td>590820</td>
      <td>77721</td>
      <td>23010</td>
      <td>51</td>
      <td>10</td>
    </tr>
    <tr>
      <th>414</th>
      <td>Congressional District 11 (113th Congress), Vi...</td>
      <td>765755</td>
      <td>69466</td>
      <td>34127</td>
      <td>96210</td>
      <td>151278</td>
      <td>15064</td>
      <td>12521</td>
      <td>59191</td>
      <td>519692</td>
      <td>...</td>
      <td>28552</td>
      <td>99017</td>
      <td>77523</td>
      <td>38531</td>
      <td>45174</td>
      <td>602751</td>
      <td>77997</td>
      <td>23027</td>
      <td>51</td>
      <td>11</td>
    </tr>
    <tr>
      <th>415</th>
      <td>Congressional District 1 (113th Congress), Was...</td>
      <td>709693</td>
      <td>79082</td>
      <td>44793</td>
      <td>51495</td>
      <td>126480</td>
      <td>9447</td>
      <td>7142</td>
      <td>42871</td>
      <td>495220</td>
      <td>...</td>
      <td>21654</td>
      <td>56361</td>
      <td>66702</td>
      <td>30246</td>
      <td>12992</td>
      <td>557526</td>
      <td>85654</td>
      <td>25063</td>
      <td>53</td>
      <td>01</td>
    </tr>
    <tr>
      <th>416</th>
      <td>Congressional District 2 (113th Congress), Was...</td>
      <td>692085</td>
      <td>87397</td>
      <td>50781</td>
      <td>31718</td>
      <td>95790</td>
      <td>7591</td>
      <td>4190</td>
      <td>54958</td>
      <td>480715</td>
      <td>...</td>
      <td>18319</td>
      <td>33584</td>
      <td>72130</td>
      <td>31418</td>
      <td>14110</td>
      <td>560492</td>
      <td>97743</td>
      <td>29299</td>
      <td>53</td>
      <td>02</td>
    </tr>
    <tr>
      <th>417</th>
      <td>Congressional District 3 (113th Congress), Was...</td>
      <td>691968</td>
      <td>114497</td>
      <td>49646</td>
      <td>26763</td>
      <td>68959</td>
      <td>6159</td>
      <td>3432</td>
      <td>57909</td>
      <td>464721</td>
      <td>...</td>
      <td>17058</td>
      <td>25816</td>
      <td>61748</td>
      <td>25096</td>
      <td>11817</td>
      <td>543869</td>
      <td>106485</td>
      <td>30083</td>
      <td>53</td>
      <td>03</td>
    </tr>
    <tr>
      <th>418</th>
      <td>Congressional District 4 (113th Congress), Was...</td>
      <td>698426</td>
      <td>90472</td>
      <td>38303</td>
      <td>20023</td>
      <td>52726</td>
      <td>4526</td>
      <td>3961</td>
      <td>41544</td>
      <td>450487</td>
      <td>...</td>
      <td>10660</td>
      <td>24354</td>
      <td>59323</td>
      <td>21145</td>
      <td>13532</td>
      <td>513239</td>
      <td>87081</td>
      <td>28733</td>
      <td>53</td>
      <td>04</td>
    </tr>
    <tr>
      <th>419</th>
      <td>Congressional District 5 (113th Congress), Was...</td>
      <td>681812</td>
      <td>98481</td>
      <td>49415</td>
      <td>30387</td>
      <td>77180</td>
      <td>7304</td>
      <td>6265</td>
      <td>60523</td>
      <td>470221</td>
      <td>...</td>
      <td>19315</td>
      <td>28287</td>
      <td>78293</td>
      <td>29357</td>
      <td>15144</td>
      <td>548600</td>
      <td>103113</td>
      <td>26050</td>
      <td>53</td>
      <td>05</td>
    </tr>
    <tr>
      <th>420</th>
      <td>Congressional District 6 (113th Congress), Was...</td>
      <td>682280</td>
      <td>95053</td>
      <td>49721</td>
      <td>34652</td>
      <td>86811</td>
      <td>9125</td>
      <td>5665</td>
      <td>81976</td>
      <td>451723</td>
      <td>...</td>
      <td>14341</td>
      <td>31310</td>
      <td>64056</td>
      <td>28687</td>
      <td>23337</td>
      <td>563423</td>
      <td>119887</td>
      <td>27613</td>
      <td>53</td>
      <td>06</td>
    </tr>
    <tr>
      <th>421</th>
      <td>Congressional District 7 (113th Congress), Was...</td>
      <td>706603</td>
      <td>51102</td>
      <td>33471</td>
      <td>78735</td>
      <td>179414</td>
      <td>24269</td>
      <td>16393</td>
      <td>36901</td>
      <td>554806</td>
      <td>...</td>
      <td>25478</td>
      <td>76557</td>
      <td>95646</td>
      <td>39750</td>
      <td>14283</td>
      <td>605602</td>
      <td>87276</td>
      <td>25472</td>
      <td>53</td>
      <td>07</td>
    </tr>
    <tr>
      <th>422</th>
      <td>Congressional District 8 (113th Congress), Was...</td>
      <td>701614</td>
      <td>104061</td>
      <td>45713</td>
      <td>39923</td>
      <td>98218</td>
      <td>6896</td>
      <td>4097</td>
      <td>52303</td>
      <td>470969</td>
      <td>...</td>
      <td>17427</td>
      <td>37086</td>
      <td>63704</td>
      <td>25907</td>
      <td>13597</td>
      <td>542317</td>
      <td>83825</td>
      <td>24869</td>
      <td>53</td>
      <td>08</td>
    </tr>
    <tr>
      <th>423</th>
      <td>Congressional District 9 (113th Congress), Was...</td>
      <td>705731</td>
      <td>87239</td>
      <td>40116</td>
      <td>50560</td>
      <td>121938</td>
      <td>11973</td>
      <td>10178</td>
      <td>37294</td>
      <td>511878</td>
      <td>...</td>
      <td>21309</td>
      <td>53454</td>
      <td>66652</td>
      <td>41614</td>
      <td>9390</td>
      <td>566974</td>
      <td>90940</td>
      <td>26711</td>
      <td>53</td>
      <td>09</td>
    </tr>
    <tr>
      <th>424</th>
      <td>Congressional District 10 (113th Congress), Wa...</td>
      <td>701194</td>
      <td>96468</td>
      <td>47471</td>
      <td>29595</td>
      <td>76957</td>
      <td>7813</td>
      <td>5718</td>
      <td>75272</td>
      <td>434025</td>
      <td>...</td>
      <td>16817</td>
      <td>23596</td>
      <td>66220</td>
      <td>28766</td>
      <td>35715</td>
      <td>548419</td>
      <td>88762</td>
      <td>33789</td>
      <td>53</td>
      <td>10</td>
    </tr>
    <tr>
      <th>425</th>
      <td>Congressional District 1 (113th Congress), Wes...</td>
      <td>617842</td>
      <td>148975</td>
      <td>31733</td>
      <td>26557</td>
      <td>51847</td>
      <td>6491</td>
      <td>4627</td>
      <td>48985</td>
      <td>447212</td>
      <td>...</td>
      <td>8815</td>
      <td>23031</td>
      <td>74720</td>
      <td>24320</td>
      <td>14598</td>
      <td>509676</td>
      <td>105810</td>
      <td>20941</td>
      <td>54</td>
      <td>01</td>
    </tr>
    <tr>
      <th>426</th>
      <td>Congressional District 2 (113th Congress), Wes...</td>
      <td>626979</td>
      <td>147006</td>
      <td>28709</td>
      <td>26052</td>
      <td>54912</td>
      <td>6100</td>
      <td>3035</td>
      <td>54226</td>
      <td>437076</td>
      <td>...</td>
      <td>14207</td>
      <td>24121</td>
      <td>62545</td>
      <td>20320</td>
      <td>23540</td>
      <td>506060</td>
      <td>105303</td>
      <td>26553</td>
      <td>54</td>
      <td>02</td>
    </tr>
    <tr>
      <th>427</th>
      <td>Congressional District 3 (113th Congress), Wes...</td>
      <td>609483</td>
      <td>142337</td>
      <td>27255</td>
      <td>18336</td>
      <td>39973</td>
      <td>4573</td>
      <td>2452</td>
      <td>47365</td>
      <td>436144</td>
      <td>...</td>
      <td>7571</td>
      <td>16030</td>
      <td>60830</td>
      <td>19470</td>
      <td>11407</td>
      <td>496991</td>
      <td>108900</td>
      <td>22433</td>
      <td>54</td>
      <td>03</td>
    </tr>
    <tr>
      <th>428</th>
      <td>Congressional District 1 (113th Congress), Wis...</td>
      <td>709472</td>
      <td>135722</td>
      <td>45821</td>
      <td>33042</td>
      <td>82885</td>
      <td>7272</td>
      <td>3471</td>
      <td>45217</td>
      <td>495728</td>
      <td>...</td>
      <td>19819</td>
      <td>29486</td>
      <td>73414</td>
      <td>25093</td>
      <td>11154</td>
      <td>561440</td>
      <td>99057</td>
      <td>31448</td>
      <td>55</td>
      <td>01</td>
    </tr>
    <tr>
      <th>429</th>
      <td>Congressional District 2 (113th Congress), Wis...</td>
      <td>733541</td>
      <td>105305</td>
      <td>46908</td>
      <td>50204</td>
      <td>114500</td>
      <td>12846</td>
      <td>12402</td>
      <td>38518</td>
      <td>532961</td>
      <td>...</td>
      <td>28081</td>
      <td>42593</td>
      <td>105245</td>
      <td>35536</td>
      <td>18111</td>
      <td>588515</td>
      <td>93327</td>
      <td>21516</td>
      <td>55</td>
      <td>02</td>
    </tr>
    <tr>
      <th>430</th>
      <td>Congressional District 3 (113th Congress), Wis...</td>
      <td>711620</td>
      <td>145960</td>
      <td>53696</td>
      <td>26737</td>
      <td>73568</td>
      <td>5184</td>
      <td>3838</td>
      <td>52086</td>
      <td>507247</td>
      <td>...</td>
      <td>19595</td>
      <td>19027</td>
      <td>88552</td>
      <td>34361</td>
      <td>13272</td>
      <td>577377</td>
      <td>111618</td>
      <td>22673</td>
      <td>55</td>
      <td>03</td>
    </tr>
    <tr>
      <th>431</th>
      <td>Congressional District 4 (113th Congress), Wis...</td>
      <td>715840</td>
      <td>110449</td>
      <td>31135</td>
      <td>30752</td>
      <td>77230</td>
      <td>7426</td>
      <td>4947</td>
      <td>32474</td>
      <td>501363</td>
      <td>...</td>
      <td>21061</td>
      <td>35252</td>
      <td>84463</td>
      <td>34183</td>
      <td>11545</td>
      <td>553095</td>
      <td>77155</td>
      <td>37340</td>
      <td>55</td>
      <td>04</td>
    </tr>
    <tr>
      <th>432</th>
      <td>Congressional District 5 (113th Congress), Wis...</td>
      <td>723153</td>
      <td>127370</td>
      <td>51366</td>
      <td>42629</td>
      <td>120204</td>
      <td>8615</td>
      <td>5481</td>
      <td>44088</td>
      <td>518507</td>
      <td>...</td>
      <td>27738</td>
      <td>35465</td>
      <td>88003</td>
      <td>29035</td>
      <td>9438</td>
      <td>580643</td>
      <td>113588</td>
      <td>20222</td>
      <td>55</td>
      <td>05</td>
    </tr>
    <tr>
      <th>433</th>
      <td>Congressional District 6 (113th Congress), Wis...</td>
      <td>713224</td>
      <td>156530</td>
      <td>47996</td>
      <td>26510</td>
      <td>83513</td>
      <td>6680</td>
      <td>3758</td>
      <td>51021</td>
      <td>506756</td>
      <td>...</td>
      <td>19388</td>
      <td>24449</td>
      <td>68253</td>
      <td>29384</td>
      <td>12138</td>
      <td>576360</td>
      <td>117405</td>
      <td>19315</td>
      <td>55</td>
      <td>06</td>
    </tr>
    <tr>
      <th>434</th>
      <td>Congressional District 7 (113th Congress), Wis...</td>
      <td>715263</td>
      <td>166694</td>
      <td>57458</td>
      <td>25853</td>
      <td>71187</td>
      <td>7178</td>
      <td>2714</td>
      <td>55682</td>
      <td>500080</td>
      <td>...</td>
      <td>20040</td>
      <td>19534</td>
      <td>76799</td>
      <td>29626</td>
      <td>13728</td>
      <td>575769</td>
      <td>128711</td>
      <td>23325</td>
      <td>55</td>
      <td>07</td>
    </tr>
    <tr>
      <th>435</th>
      <td>Congressional District 8 (113th Congress), Wis...</td>
      <td>720600</td>
      <td>156452</td>
      <td>54636</td>
      <td>27094</td>
      <td>88764</td>
      <td>5705</td>
      <td>2442</td>
      <td>49593</td>
      <td>503200</td>
      <td>...</td>
      <td>22851</td>
      <td>27058</td>
      <td>73709</td>
      <td>31343</td>
      <td>11282</td>
      <td>571846</td>
      <td>107746</td>
      <td>23479</td>
      <td>55</td>
      <td>08</td>
    </tr>
    <tr>
      <th>436</th>
      <td>Congressional District (at Large) (113th Congr...</td>
      <td>582658</td>
      <td>90150</td>
      <td>41261</td>
      <td>22938</td>
      <td>68225</td>
      <td>5025</td>
      <td>5815</td>
      <td>48979</td>
      <td>391350</td>
      <td>...</td>
      <td>11671</td>
      <td>17435</td>
      <td>72719</td>
      <td>28909</td>
      <td>21411</td>
      <td>458613</td>
      <td>77554</td>
      <td>15775</td>
      <td>56</td>
      <td>00</td>
    </tr>
    <tr>
      <th>437</th>
      <td>Resident Commissioner District (at Large) (113...</td>
      <td>3615086</td>
      <td>590396</td>
      <td>233730</td>
      <td>112725</td>
      <td>416877</td>
      <td>32498</td>
      <td>22969</td>
      <td>88933</td>
      <td>2710960</td>
      <td>...</td>
      <td>54258</td>
      <td>107157</td>
      <td>264590</td>
      <td>94904</td>
      <td>92020</td>
      <td>2905959</td>
      <td>599663</td>
      <td>235338</td>
      <td>72</td>
      <td>98</td>
    </tr>
  </tbody>
</table>
<p>437 rows × 36 columns</p>
</div>




```python
#covert isolated dataframe to numeric
isolated = dataFrame[(dataFrame['Name of District'] == "Congressional District 45 (113th Congress), California")]
isoNumeric = isolated['Total Population']   
isoNumeric = pd.to_numeric(isoNumeric)

```


```python
#find average population of congressional district
s = dataFrame['Total Population']
s = pd.to_numeric(s)
avg_pop = s.mean()
avg_pop
```




    731679.4622425629




```python
#find population of irvine congress district
isolated_pop = isolated['Total Population'].mean()
isolated_pop
```




    733706.0




```python
popNames = ['Congressional District 45', 'Average']
popNums = [isolated_pop, avg_pop]
```


```python
# Population vs Average
plt.bar(popNames, popNums, align='center', alpha=0.5)
plt.ylabel('Total Population')
plt.title('District vs. Average Population')
axes = plt.gca()
min_pop = s.min()
axes.set_ylim([min_pop,800000])
plt.show()
```


![png](output_10_0.png)



```python
# INDUSTRY PIE
labels = ["Agriculture, forestry, fishing and hunting, and mining","Construction","Manufacturing","Wholesale Trade","Retail Trade","Transportation and warehousing, and utilities","INFORMATION","Finance and insurance, and real estate and rental and leasing","Professional, scientific, and management, and administrative and waste management services","Educational services, and health care and social assistance","Arts, entertainment, and recreation, and accommodation and food services"] 





data = [isolated["Agriculture, forestry, fishing and hunting, and mining"],isolated["Construction"],isolated["Manufacturing"],isolated["Wholesale Trade"],isolated["Retail Trade"],isolated["Transportation and warehousing, and utilities"],isolated["INFORMATION"],isolated["Finance and insurance, and real estate and rental and leasing"],isolated["Professional, scientific, and management, and administrative and waste management services"],isolated["Educational services, and health care and social assistance"],isolated["Arts, entertainment, and recreation, and accommodation and food services"] ]
numeric_data = []

for x in data:
    numeric_data.append(pd.to_numeric(x[66]))
    
pie = plt.pie(x=numeric_data,labels=labels,data=numeric_data,autopct='%.2f', shadow=True,radius=4)
plt.axis("equal")
plt.title("Industry Breakdown", fontsize = 20)
plt.show()

```


![png](output_11_0.png)



```python
EducationGraph = dataFrame[["Name of District","High School Diploma","Associates Degree","Bachelor's","Masters","Professional","Doctorate"]]
EducationGraph= pd.DataFrame(EducationGraph)
IrvineEducation = EducationGraph[(EducationGraph['Name of District'] == "Congressional District 45 (113th Congress), California")]
EdTranspose = IrvineEducation.T
EdTDrop = EdTranspose.drop(["Name of District"])
EdTDrop[66] = EdTDrop[66].astype(str).astype(int)
EdTDrop
font = FontProperties()
font.set_family('serif')
font.set_name('Times New Roman')
font.set_style('normal')
ax = EdTDrop[[66]].plot(kind='bar', figsize=(20, 10), legend=False, fontsize=20)
ax.set_title("Education Attainment Level", fontsize = 35)
ax.set_xlabel("Education Level", fontsize=18)
ax.set_ylabel("Number of People", fontsize=18)
ax.yaxis.set_major_formatter(tkr.FuncFormatter(lambda y,  p: format(int(y), ',')))
plt.setp(ax.get_xticklabels(), rotation="horizontal", fontsize=15)
plt.setp(ax.get_yticklabels(), fontsize=15)
plt.show()
```


![png](output_12_0.png)



```python
EthnicityGraph = dataFrame[["Name of District","White","African American","Native American/Alaskan","Asian","Native Hawaiian/Pacific Islander","OtherRace"]]
EthnicityGraph= pd.DataFrame(EthnicityGraph)

IrvineEthnicity = EthnicityGraph[(EthnicityGraph['Name of District'] == "Congressional District 45 (113th Congress), California")]
EthTranspose = IrvineEthnicity.T
EthTDrop = EthTranspose.drop(["Name of District"])
EthTDrop[66] = EthTDrop[66].astype(str).astype(int)
data = EthTDrop[66]
labels = "White","African American","Native American/Alaskan","Asian","Native Hawaiian/Pacific Islander","OtherRace"
figure(1, figsize=(10,10))

fracs =data
plt.pie(fracs, labels=labels,startangle=90)
title("Population by Race", fontsize = 20)

show()

```


![png](output_13_0.png)



```python
VeteranGraph = dataFrame[["Name of District","Veteran","Non-Veteran"]]
VeteranGraph= pd.DataFrame(VeteranGraph)

IrvineVet = VeteranGraph[(VeteranGraph['Name of District'] == "Congressional District 45 (113th Congress), California")]
VetTranspose = IrvineVet.T
VetData = VetTranspose.drop(["Name of District"])
VetData[66] = VetData[66].astype(str).astype(int)
data2 = VetData[66]
labels = "Veteran","Non-Veteran"
figure(1, figsize=(6,6))

fracs = data2
plt.pie(fracs, labels=labels,startangle=90)
title("Veteran Vs Non-Veteran Population", fontsize = 20)

show()
```


![png](output_14_0.png)



```python
data = [isolated["Total Unemployed"],isolated["TotalLaborPopulation"]]
numeric_data = []
unemploymentAvg = (pd.to_numeric(dataFrame["Total Unemployed"])/pd.to_numeric(dataFrame["TotalLaborPopulation"])).mean()
unemploymentAvg = unemploymentAvg*100
for x in data:
    numeric_data.append(pd.to_numeric(x[66]))
unemploymentIsolated = (numeric_data[0]/numeric_data[1])*100
unemployment = [unemploymentIsolated, unemploymentAvg]
names = ["District Unemployment", "Average Unemployment"]
plt.bar(names, unemployment, align='center', alpha=0.5)
title("District Unemployment vs Avg", size=20)
plt.show()
```


![png](output_15_0.png)



```python
citizenship_df = dataFrame[(dataFrame['Name of District'] == "Congressional District 45 (113th Congress), California")]
citizenship_df1 = citizenship_df[['U.S. citizen', 'Non U.S. citizen']]
citizenship_df1

labels = ["U.S. citizen", "Non U.S. citizen"]

# The values of each section of the pie chart
sizes = [529445, 76680]

# The colors of each section of the pie chart
#colors = ["yellowgreen", "red", "lightcoral", "lightskyblue", "black", "brown",]
colors = ["#ffcc99", "#66b3ff"]

# Tells matplotlib to seperate the "Python" section from the others
explode = (0.1, 0)
plt.pie(sizes, explode=explode, labels=labels, colors=colors, autopct="%1.1f%%", shadow=True, startangle=140)
plt.axis("equal")
# Save Figure
plt.savefig("CitizenData.png")
plt.show()
```


![png](output_16_0.png)



```python
#Tim
```


```python
#find total population of congressional district
cd_pop = dataFrame['Total Population']
cd_pop = pd.to_numeric(cd_pop)
tot_cd_population = cd_pop.sum()
```


```python
#find total incomes below poverty in congressional district
cd_poverty = dataFrame['Income in the past 12 months below poverty level']
cd_poverty = pd.to_numeric(cd_poverty)
tot_cd_income_below_poverty = cd_poverty.sum()
```


```python
cd_poverty_rate = tot_cd_income_below_poverty  / tot_cd_population
```


```python
api_key = 'a770489433124a44654119b16edfb8291b8efa25'
```


```python
url_US_pop = 'https://api.census.gov/data/2013/acs1?get=NAME,B01003_001E&for=metropolitan%20statistical%20area/micropolitan%20statistical%20area:*&key='
url_US_poverty = 'https://api.census.gov/data/2013/acs1?get=NAME,B17001_002E&for=metropolitan%20statistical%20area/micropolitan%20statistical%20area:*&key='
```


```python

#query for pop response
pop_response = requests.get(url_US_pop)
pop_json = pop_response.json()

#query for poverty status response (married)
poverty_response = requests.get(url_US_poverty)
poverty_json = poverty_response.json()
```


```python

#view json - pop
pop_json[0:3]
```




    [['NAME',
      'B01003_001E',
      'metropolitan statistical area/micropolitan statistical area'],
     ['Aguadilla-Isabela, PR Metro Area', '327847', '10380'],
     ['Arecibo, PR Metro Area', '195036', '11640']]




```python
#view json for poverty status
poverty_json[0:3]
```




    [['NAME',
      'B17001_002E',
      'metropolitan statistical area/micropolitan statistical area'],
     ['Aguadilla-Isabela, PR Metro Area', '175192', '10380'],
     ['Arecibo, PR Metro Area', '88681', '11640']]




```python

# Convert pop to to Data Frame
pop_US_df =pd.DataFrame(pop_json)
pop_US_df.columns = pop_US_df.iloc[0]

# Convert poverty Income to to Data Frame
poverty_US_df =pd.DataFrame(poverty_json)
poverty_US_df.columns = poverty_US_df.iloc[0]
```


```python

#US population
pop_US_df2 = pop_US_df.drop([0])
pop_US_df = pop_US_df2.rename(columns={"B01003_001E":"population" , "metropolitan statistical area/micropolitan statistical area" : "MSA"})
```


```python
#convert to numeric
pop_US_df['population'] = pd.to_numeric(pop_US_df['population'])
```


```python
#poverty
poverty_US_df2 = poverty_US_df.drop([0])
poverty_US_df = poverty_US_df2.rename(columns={"B17001_002E":"poverty Income" , "metropolitan statistical area/micropolitan statistical area" : "MSA"})
```


```python
#convert to numeric
poverty_US_df['poverty Income'] = pd.to_numeric(poverty_US_df['poverty Income'])
```


```python
#US population tot
Tot_US_Population = pop_US_df['population'].sum()
```


```python
# tot US income below poverty
tot_income_below_poverty = poverty_US_df['poverty Income'].sum()
```


```python
#US poverty rate
US_poverty_rate = tot_income_below_poverty / Tot_US_Population
```


```python
#find total population of congressional district
cd_pop = dataFrame['Total Population']
cd_pop = pd.to_numeric(cd_pop)
tot_cd_population = cd_pop.sum()
```


```python
#find total incomes below poverty in congressional district
cd_poverty = dataFrame['Income in the past 12 months below poverty level']
cd_poverty = pd.to_numeric(cd_poverty)
tot_cd_income_below_poverty = cd_poverty.sum()
```


```python
#congressional district poverty rate
cd_poverty_rate = tot_cd_income_below_poverty  / tot_cd_population
```


```python
# Create an array that contains the number of users each language has
Poverty_Rates = [US_poverty_rate, cd_poverty_rate]
x_axis =  ['U.S.', '45th Dist']
```


```python
# Tell matplotlib that we will be making a bar chart
# Users is our y axis and x_axis is, of course, our x axis
# We apply align="edge" to ensure our bars line up with our tick marks

plt.ylim(.12, max(Poverty_Rates)+.01)
plt.title("Poverty Rates - U.S. & 45th Congessional District")
plt.xlabel("Region")
plt.ylabel("Poverty Rate")
plt.bar(x_axis, Poverty_Rates, color='r' , alpha=0.5, align="center")
plt.show()
```


![png](output_38_0.png)

